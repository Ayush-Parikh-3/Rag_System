import streamlit as st
import requests
import os
import json
import hashlib
from pathlib import Path
from typing import Optional

from github_fetcher import fetch_repo_files
from chunker import chunk_documents
from embedder import embed_texts, embed_query
from vector_store import VectorStore
from rag_chain import generate_answer

# ─── Page Config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="gitRAG — GitHub Knowledge Search",
    page_icon="🔍",
    layout="wide",
)

# ─── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    .stApp { background-color: #0d0f14; color: #e8eaf0; }
    .main-title { font-size: 2rem; font-weight: 800; color: #3bff9e; }
    .source-chip {
        display: inline-block; background: #1a1e28; border: 1px solid #333;
        border-radius: 4px; padding: 2px 8px; font-size: 12px;
        color: #9ca3af; margin: 2px;
    }
    .user-msg {
        background: rgba(59,255,158,0.1); border: 1px solid rgba(59,255,158,0.25);
        border-radius: 8px; padding: 10px 14px; margin: 4px 0;
    }
    .assistant-msg {
        background: #13161e; border: 1px solid rgba(255,255,255,0.07);
        border-radius: 8px; padding: 10px 14px; margin: 4px 0;
    }
</style>
""", unsafe_allow_html=True)

# ─── Session State ─────────────────────────────────────────────────────────────
if "vector_stores" not in st.session_state:
    st.session_state.vector_stores = {}       # key → VectorStore
if "repo_meta" not in st.session_state:
    st.session_state.repo_meta = {}           # key → dict
if "current_repo" not in st.session_state:
    st.session_state.current_repo = None
if "messages" not in st.session_state:
    st.session_state.messages = {}            # key → list of {role, content, sources}

# ─── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown('<div class="main-title">git<span>RAG</span> 🔍</div>', unsafe_allow_html=True)
    st.caption("GitHub Repository RAG System")
    st.divider()

    st.subheader("Load Repository")
    repo_url   = st.text_input("GitHub URL", placeholder="https://github.com/owner/repo")
    branch     = st.text_input("Branch", value="main")
    gh_token   = st.text_input("GitHub Token (optional)", type="password",
                               help="Increases API rate limit from 60 → 5000 req/hr")
    groq_key   = st.text_input("Groq API Key", type="password",
                               help="Get free key at console.groq.com")
    load_btn   = st.button("⬇ Load & Index Repository", use_container_width=True)

    st.divider()
    if st.session_state.repo_meta:
        st.subheader("Loaded Repos")
        for key, meta in st.session_state.repo_meta.items():
            label = f"📦 {meta['owner']}/{meta['repo']}"
            if st.button(label, key=f"sel_{key}", use_container_width=True):
                st.session_state.current_repo = key
                st.rerun()

# ─── Load Repo Logic ───────────────────────────────────────────────────────────
if load_btn and repo_url:
    import re
    match = re.match(r"https?://github\.com/([^/]+)/([^/\s]+)", repo_url)
    if not match:
        st.error("Invalid GitHub URL. Use: https://github.com/owner/repo")
    else:
        owner, repo_name = match.group(1), match.group(2).rstrip("/")
        repo_key = f"{owner}_{repo_name}"

        if repo_key in st.session_state.vector_stores:
            st.info("Repository already indexed. Selecting it.")
            st.session_state.current_repo = repo_key
        else:
            with st.status(f"Indexing {owner}/{repo_name}…", expanded=True) as status:

                st.write("📡 Fetching file list from GitHub API…")
                docs = fetch_repo_files(owner, repo_name, branch, gh_token or None)
                st.write(f"✅ Found **{len(docs)}** supported files")

                st.write("✂️ Chunking documents…")
                chunks = chunk_documents(docs)
                st.write(f"✅ Created **{len(chunks)}** chunks")

                st.write("🧠 Generating embeddings (all-MiniLM-L6-v2)…")
                texts = [c["text"] for c in chunks]
                embeddings = embed_texts(texts)
                st.write(f"✅ Embedded {len(embeddings)} chunks")

                st.write("🗄️ Storing in ChromaDB…")
                vs = VectorStore(collection_name=repo_key)
                vs.add(chunks, embeddings)
                st.write("✅ Vector store ready")

                st.session_state.vector_stores[repo_key] = vs
                st.session_state.repo_meta[repo_key] = {
                    "owner": owner,
                    "repo": repo_name,
                    "branch": branch,
                    "files": len(docs),
                    "chunks": len(chunks),
                    "url": repo_url,
                    "groq_key": groq_key,
                }
                st.session_state.messages[repo_key] = []
                st.session_state.current_repo = repo_key
                status.update(label="✅ Repository indexed!", state="complete")

# ─── Main Chat Area ────────────────────────────────────────────────────────────
if st.session_state.current_repo is None:
    st.markdown("## 👈 Load a GitHub repository to get started")
    st.markdown("""
    **How it works:**
    1. Paste any public GitHub repo URL in the sidebar
    2. The system fetches, chunks, and embeds all supported files
    3. Ask natural language questions — answers are grounded in the code
    4. Source file links are shown with every answer

    **Supported file types:** `.md` `.txt` `.py` `.js` `.ts` `.json` `.html` `.css` `.yaml` `.sh` `.go` `.rs` `.java` `.cpp`
    """)
else:
    key  = st.session_state.current_repo
    meta = st.session_state.repo_meta[key]
    vs   = st.session_state.vector_stores[key]

    # Header
    col1, col2, col3 = st.columns([4, 1, 1])
    with col1:
        st.markdown(f"### 📦 `{meta['owner']}/{meta['repo']}`")
        st.caption(f"Branch: `{meta['branch']}` · {meta['files']} files · {meta['chunks']} chunks")
    with col2:
        st.metric("Files", meta["files"])
    with col3:
        st.metric("Chunks", meta["chunks"])

    st.divider()

    # Chat history
    msgs = st.session_state.messages.get(key, [])
    for m in msgs:
        if m["role"] == "user":
            with st.chat_message("user"):
                st.markdown(m["content"])
        else:
            with st.chat_message("assistant"):
                st.markdown(m["content"])
                if m.get("sources"):
                    st.markdown("**Sources:**")
                    src_html = " ".join(
                        f'<a href="{s["url"]}" target="_blank" class="source-chip">📄 {s["path"].split("/")[-1]}</a>'
                        for s in m["sources"]
                    )
                    st.markdown(src_html, unsafe_allow_html=True)

    # Query input
    query = st.chat_input("Ask anything about this repository…")
    if query:
        # Show user message
        st.session_state.messages[key].append({"role": "user", "content": query})
        with st.chat_message("user"):
            st.markdown(query)

        with st.chat_message("assistant"):
            with st.spinner("Searching knowledge base…"):
                # Retrieve
                q_emb = embed_query(query)
                results = vs.search(q_emb, top_k=6)

                # Generate
                groq_key = meta.get("groq_key") or os.getenv("GROQ_API_KEY", "")
                answer = generate_answer(
                    query=query,
                    chunks=results,
                    owner=meta["owner"],
                    repo=meta["repo"],
                    groq_api_key=groq_key,
                )

            st.markdown(answer)
            if results:
                st.markdown("**Sources:**")
                seen = set()
                src_html = ""
                for r in results:
                    p = r["metadata"]["path"]
                    if p not in seen:
                        seen.add(p)
                        url = r["metadata"]["url"]
                        src_html += f'<a href="{url}" target="_blank" class="source-chip">📄 {p.split("/")[-1]}</a> '
                st.markdown(src_html, unsafe_allow_html=True)

            st.session_state.messages[key].append({
                "role": "assistant",
                "content": answer,
                "sources": [{"path": r["metadata"]["path"], "url": r["metadata"]["url"]} for r in results],
            })
